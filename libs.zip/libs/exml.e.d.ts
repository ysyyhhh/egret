declare class AdClickMisleadViewSkin extends eui.Skin{
}
declare class AdFullScreenItemSkin extends eui.Skin{
}
declare class AdFullScreenScrollViewSkin extends eui.Skin{
}
declare class AdFullScreenSupperScrollViewSkin extends eui.Skin{
}
declare class AdGameFinishScrollViewSkin extends eui.Skin{
}
declare class AdGameItemSkin extends eui.Skin{
}
declare class AdGridItemSkin extends eui.Skin{
}
declare class AdGridlViewSkin extends eui.Skin{
}
declare class AdHorizontalScrollViewExSkin extends eui.Skin{
}
declare class AdHorizontalScrollViewSkin extends eui.Skin{
}
declare class AdItemNotTitleSkin extends eui.Skin{
}
declare class AdItemSkin extends eui.Skin{
}
declare class AdNewFullScreenItemSkin extends eui.Skin{
}
declare class AdResultItemSkin extends eui.Skin{
}
declare class HotGameIconSkin extends eui.Skin{
}
declare class BackgroundItemSkin extends eui.Skin{
}
declare class BallItemSkin extends eui.Skin{
}
declare class CheckBoxButtonSkin extends eui.Skin{
}
declare class ChipsButtonSkin extends eui.Skin{
}
declare class ConfirmPanelSkin extends eui.Skin{
}
declare class MenuBarSkin extends eui.Skin{
}
declare class RoundItemSkin extends eui.Skin{
}
declare class SkinItemSkin extends eui.Skin{
}
declare class TipsSkin extends eui.Skin{
}
declare class GameFailViewSkin extends eui.Skin{
}
declare class GameRankViewSkin extends eui.Skin{
}
declare class GameSkinViewSkin extends eui.Skin{
}
declare class GameSuccessViewSkin extends eui.Skin{
}
declare class GameViewSkin extends eui.Skin{
}
declare class InquiryEnterGameSkin extends eui.Skin{
}
declare class PublicLoadingSkin extends eui.Skin{
}
declare class MainViewSkin extends eui.Skin{
}
declare class MisTouchGifBoxSkin extends eui.Skin{
}
declare class RewardViewSkin extends eui.Skin{
}
declare class SettingViewSkin extends eui.Skin{
}
declare class SiginItemSkin extends eui.Skin{
}
declare class SiginViewSkin extends eui.Skin{
}
